#Q1 -Divisible by 7 and 5

for i in range(1500, 2701):
    if i % 7 == 0 and i % 5 == 0:
        print(i)
#Q2 -Celsius and Fahrenheit

c = float(input("Enter Celsius: "))
f = (c * 9 / 5) + 32
print("Fahrenheit:", f)

f = float(input("Enter Fahrenheit: "))
c = (f - 32) * 5 / 9
print("Celsius:", c)


#Q3 — Guessing Game

number = 5

while True:
    guess = int(input("Guess a number between 1 and 9: "))

    if guess == number:
        print("Well guessed!")
        break # stops the loop if user guesses the correct number


#Q4 — Star Pattern

for i in range(1, 6):
    for j in range(i):
        print("*", end=" ")
    print()

for i in range(4, 0, -1):
    for j in range(i):
        print("*", end=" ")
    print()

#Q5 — Reverse Word

word = input("Enter a word: ")

print(word[::-1])

#Q6 — Even and Odd Count

numbers = (1, 2, 3, 4, 5, 6, 7, 8, 9)

even = 0
odd = 0

for i in numbers:
    if i % 2 == 0:
        even += 1
    else:
        odd += 1

print("Number of even numbers:", even)
print("Number of odd numbers:", odd)

#Q7 — Data Types

datalist = [1452, 11.23, 1+2j, True, 'w3resource',
            (0, -1), [5, 12],
            {"class": "V", "section": "A"}]

for item in datalist:
    print(item, type(item))

#Q8 — Continue Statement

for i in range(7):
    if i == 3 or i == 6:
        continue

    print(i)

#Q9 — Fibonacci Series

a = 0
b = 1

while a <= 50:
    print(a, end=" ")
    a, b = b, a + b


#FizzBuzz — Unnumbered Question in the PDF

for i in range(1, 51):
    if i % 3 == 0 and i % 5 == 0:
        print("FizzBuzz")
    elif i % 3 == 0:
        print("Fizz")
    elif i % 5 == 0:
        print("Buzz")
    else:
        print(i)

#Q10 — 2D Array

m = int(input("Enter rows: "))
n = int(input("Enter columns: "))

array = []

for i in range(m):
    row = []

    for j in range(n):
        row.append(i * j)

    array.append(row)

print(array)


#Q11 — Lowercase Lines

while True:
    line = input()

    if line == "":
        break

    print(line.lower())

#Q12 — Binary Numbers Divisible by 5

numbers = input("Enter binary numbers: ").split(",")

result = []

for num in numbers:
    decimal = int(num, 2)

    if decimal % 5 == 0:
        result.append(num)

print(",".join(result))

#Q13 — Count Letters and Digits

text = input("Enter a string: ")

letters = 0
digits = 0

for i in text:
    if i.isalpha():
        letters += 1
    elif i.isdigit():
        digits += 1

print("Letters", letters)
print("Digits", digits)


#Q14 — Password Validator

password = input("Enter password: ")

lower = 0
upper = 0
digit = 0
special = 0

for i in password:
    if i.islower():
        lower = 1
    elif i.isupper():
        upper = 1
    elif i.isdigit():
        digit = 1
    elif i in "$#@":
        special = 1

if len(password) >= 6 and len(password) <= 16:
    if lower == 1 and upper == 1 and digit == 1 and special == 2:
        print("Valid Password")
    else:
        print("Invalid Password")
else:
    print("Invalid Password")